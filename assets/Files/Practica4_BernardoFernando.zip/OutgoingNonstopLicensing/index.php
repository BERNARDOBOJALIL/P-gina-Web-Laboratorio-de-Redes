<?php
  // Redirect to our HTML file
  header('Location: index.html');
?>